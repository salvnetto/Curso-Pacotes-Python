def verificar_numero_valido(x):
    assert isinstance(x, int), "O valor fornecido não é um inteiro"